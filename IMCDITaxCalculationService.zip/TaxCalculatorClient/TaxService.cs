﻿using System;
using TaxServiceCore.Entities;
using TaxServiceCore.Interface;

namespace TaxCalculatorClient
{
    public class TaxService : ITax
    {
        public ITax TaxCalculator;
        public TaxService(ITax _taxCalculator)
        {
            TaxCalculator = _taxCalculator;
        }
        public TSRateResponse GetTaxForLocation(string zipCode)
        {
           return TaxCalculator.GetTaxForLocation(zipCode);
        }

        public TSTaxResponse GetTaxForOrder(TSOrder order)
        {
            return TaxCalculator.GetTaxForOrder(order);
        }
    }
}
