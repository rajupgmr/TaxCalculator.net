﻿using System;
using System.Collections.Generic;
using TaxServiceCore.Entities;

namespace TaxCalculatorClient
{
    public class Program
    {   
        static void Main(string[] args)
        {           
            TaxService taxServiceClient = new TaxService(new TaxCalculator());
            //Since TaxJax library is available in the Nuget PM, used it for calling services
            var taxResultForLoc = taxServiceClient.GetTaxForLocation("01581");
            Console.WriteLine(string.Format("{0} = {1}", "State tax ", taxResultForLoc.StateRate));
            Console.WriteLine(string.Format("{0} = {1}", "Combined Rate tax ", taxResultForLoc.CombinedRate));

            var order = GetOrderDto();
            var orderTaxResult = taxServiceClient.GetTaxForOrder(order);

            Console.WriteLine(string.Format("{0} = {1}", "Tax to be collected ($)", orderTaxResult.AmountToCollect));
            Console.ReadLine();

            //Note: Exception logging to DB or file not implemented
            //Note: Since consuming TaxJax using NPM is simple, Impleneted solution using it
            //Otherwise, HTTPClient or HTTPSClient implementation to consume the service would have been implemented
            //Solution desinged to keep it very simple to provide the solution
        }
        public static TSOrder GetOrderDto()
        {
            return new TSOrder()
            {
                FromCountry = "US",
                FromZip = "92093",
                FromState = "CA",
                FromCity = "La Jolla",
                FromStreet = "9500 Gilman Drive",
                ToCountry = "US",
                ToZip = "90002",
                ToState = "CA",
                ToCity = "Los Angeles",
                ToStreet = "1335 E 103rd St",
                Amount = 15,
                Shipping = Convert.ToDecimal(1.5),
                LineItems = new List<OrderLineItem>{
                                        new OrderLineItem() {
                                          Id = "1",
                                          Quantity = 1,
                                          ProductTaxCode = "20010",
                                          UnitPrice = 15,
                                          Discount = 0
                                        }
                                      }
            };
        }
    }
}
