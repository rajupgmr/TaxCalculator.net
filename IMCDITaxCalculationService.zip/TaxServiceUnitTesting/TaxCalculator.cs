﻿using System;
using TaxServiceCore.Entities;
using TaxServiceCore.Interface;
using TaxServiceCore.Helpers;


namespace TaxCalculatorClient
{
    public class TaxCalculator : ITax
    {
        public string Key { get { return "5da2f821eee4035db4771edab942a4cc"; } }
        public TSRateResponse GetTaxForLocation(string zipCode)
        {
            return TaxServiceHelper.RatesForLocation(Key,zipCode);           
        }

        public TSTaxResponse GetTaxForOrder(TSOrder order)
        {
            return TaxServiceHelper.TaxForOrder(Key, order);
        }
    }
}
