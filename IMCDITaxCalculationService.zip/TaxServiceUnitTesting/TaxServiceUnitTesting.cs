using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using TaxCalculatorClient;
using TaxServiceCore.Entities;

namespace TaxServiceUnitTesting
{
    [TestClass]
    public class TaxServiceUnitTesting
    {
        [TestMethod]
        public void TestTaxForLocation()
        {
            TaxService taxServiceClient = new TaxService(new TaxCalculator());
            var taxResultForLoc = taxServiceClient.GetTaxForLocation("01581");
            Assert.IsNotNull(taxResultForLoc);
            Assert.AreEqual(taxResultForLoc.StateRate, Convert.ToDecimal(0.0625));
        }

        [TestMethod]
        public void TestTaxForOrder()
        {
            TaxService taxServiceClient = new TaxService(new TaxCalculator());
            var orderTaxResult = taxServiceClient.GetTaxForOrder(new TSOrder()
            {
                FromCountry = "US",
                FromZip = "92093",
                FromState = "CA",
                FromCity = "La Jolla",
                FromStreet = "9500 Gilman Drive",
                ToCountry = "US",
                ToZip = "90002",
                ToState = "CA",
                ToCity = "Los Angeles",
                ToStreet = "1335 E 103rd St",
                Amount = 15,
                Shipping = Convert.ToDecimal(1.5),
                LineItems = new List<OrderLineItem>{
                                        new OrderLineItem() {
                                          Id = "1",
                                          Quantity = 1,
                                          ProductTaxCode = "20010",
                                          UnitPrice = 15,
                                          Discount = 0
                                        }
                                      }
            });
            Assert.IsNotNull(orderTaxResult);
            Assert.AreEqual(orderTaxResult.TaxableAmount, Convert.ToDecimal(15.0));
        }
    }
}
