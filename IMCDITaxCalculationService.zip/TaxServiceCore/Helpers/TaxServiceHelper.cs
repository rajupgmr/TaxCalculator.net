﻿using System;
using Taxjar;
using TaxServiceCore.Entities;

namespace TaxServiceCore.Helpers
{
    public static class TaxServiceHelper
    {

        //public static TSRateResponse RateForLocation(string key, string zipCode)
        //{
        //    using (var client = new HttpClient())
        //    {
        //        // Authorizing with token 
        //        client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);

        //        var url = config["ServiceUrl"];
        //        client.BaseAddress = new Uri(url);

        //        // We want the response to be JSON.
        //        client.DefaultRequestHeaders.Accept.Clear();
        //        client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

        //        // make the request
        //        HttpResponseMessage response = await client.GetAsync(url + zipCode);
        //        //response.EnsureSuccessStatusCode();

        //        // parse the response and return the data.
        //        string jsonString = await response.Content.ReadAsStringAsync();
        //        var responseData = JsonConvert.DeserializeObject(jsonString);


        //        //TODO: Mapper Implementation add below

        //        return (dynamic)responseData;

        //    }
        //}
        public  static TSRateResponse RatesForLocation(string key, string zipCode)
        {
            var client = new TaxjarApi(key);
            var result= client.RatesForLocation(zipCode);
            var rateResponse = new TSRateResponse
            {
                StateRate = result.StateRate,
                CombinedRate = result.CombinedRate
            };
            return rateResponse;

        }

        public static TSTaxResponse TaxForOrder(string key, TSOrder order)
        {
            var client = new TaxjarApi(key);
            var result = client.TaxForOrder(order);
            var tsResult = new TSTaxResponse
            {
                AmountToCollect = result.AmountToCollect,
                TaxableAmount = result.TaxableAmount
            };
            return tsResult;

        }
    }
}
