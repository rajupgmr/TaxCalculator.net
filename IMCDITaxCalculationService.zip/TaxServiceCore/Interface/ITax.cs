﻿using System;
using System.Collections.Generic;
using System.Text;
using TaxServiceCore.Entities;

namespace TaxServiceCore.Interface
{
    public interface ITax
    {
        TSRateResponse GetTaxForLocation(string zipCode);
        TSTaxResponse GetTaxForOrder(TSOrder order);
    }
}
